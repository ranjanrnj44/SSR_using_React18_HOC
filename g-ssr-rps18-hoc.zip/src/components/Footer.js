import React from "react";

function Footer() {
  return (
    <>
      <p className="footer">Susp END</p>
    </>
  );
}

export default Footer;
